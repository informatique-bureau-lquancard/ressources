package com.blq.fr.gestionDesOffresBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDesOffresBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDesOffresBackendApplication.class, args);
	}

}
