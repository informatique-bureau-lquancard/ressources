package com.blq.fr.gestionDesOffresBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDesOffresBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
